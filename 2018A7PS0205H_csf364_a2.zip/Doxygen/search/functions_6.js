var searchData=
[
  ['setx_32',['setX',['../classPoint.html#acdc86ab607b2ae8415152883e2629015',1,'Point']]],
  ['sety_33',['setY',['../classPoint.html#afccad787a359f062efc1af5e935a99ba',1,'Point']]]
];
