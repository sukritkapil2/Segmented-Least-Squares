var searchData=
[
  ['line_28',['Line',['../classLine.html#acc11b8a429d8cdd63ba6803dff5602b3',1,'Line::Line()'],['../classLine.html#afeaa676c7d249d582c5766dc732a78e2',1,'Line::Line(Point p1, Point p2)']]]
];
