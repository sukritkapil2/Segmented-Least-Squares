var searchData=
[
  ['getp1_24',['getP1',['../classLine.html#a77926f85132da725e45eb6dbd1404810',1,'Line']]],
  ['getp2_25',['getP2',['../classLine.html#ae8239123e290333122659300a20b78f1',1,'Line']]],
  ['getx_26',['getX',['../classPoint.html#a0b82a4aa9614c11854abc507d89a70a9',1,'Point']]],
  ['gety_27',['getY',['../classPoint.html#a3770f321c49dfe7ca463900fddc2e2bc',1,'Point']]]
];
