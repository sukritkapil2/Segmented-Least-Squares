var searchData=
[
  ['point_31',['Point',['../classPoint.html#ad92f2337b839a94ce97dcdb439b4325a',1,'Point::Point()'],['../classPoint.html#a001c4958c310b248f5c26037aea38a9c',1,'Point::Point(int x, int y)']]]
];
