var searchData=
[
  ['primitives_2ecpp_20',['primitives.cpp',['../primitives_8cpp.html',1,'']]],
  ['primitives_2eh_21',['primitives.h',['../primitives_8h.html',1,'']]]
];
