var searchData=
[
  ['findsegmentedleastsquares_0',['FindSegmentedLeastSquares',['../primitives_8cpp.html#a26c50402b2d837957b21a966d65581f9',1,'FindSegmentedLeastSquares(vector&lt; Point &gt; V, double C):&#160;primitives.cpp'],['../primitives_8h.html#a26c50402b2d837957b21a966d65581f9',1,'FindSegmentedLeastSquares(vector&lt; Point &gt; V, double C):&#160;primitives.cpp']]]
];
