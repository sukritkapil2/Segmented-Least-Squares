var searchData=
[
  ['line_5',['Line',['../classLine.html',1,'Line'],['../classLine.html#acc11b8a429d8cdd63ba6803dff5602b3',1,'Line::Line()'],['../classLine.html#afeaa676c7d249d582c5766dc732a78e2',1,'Line::Line(Point p1, Point p2)'],['../classvisualization_1_1Line.html',1,'visualization.Line']]]
];
